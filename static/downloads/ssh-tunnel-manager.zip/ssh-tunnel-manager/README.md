# SSH 隧道管理器

一个精美的 Windows SSH 隧道管理工具，带仪表盘 GUI 和系统托盘支持。

## 功能

- Canvas 渐变卡片 UI，暗色主题
- 实时连接状态监控（状态灯 + 脉冲动画）
- 延迟曲线图 + 健康条
- 自动重连（指数退避）
- 系统托盘驻留 + 通知
- 开机自启支持（可选）
- 连接统计记录

## 依赖

```
pip install netifaces pystray Pillow
```

系统要求：Python 3.10+、Windows、SSH 客户端

## 使用

1. 复制配置文件：
   ```
   copy config.json.example config.json
   ```
2. 编辑 `config.json`，填入你的服务器信息：
   - `ecs_host` — SSH 服务器 IP
   - `ssh_user` — SSH 用户名
   - `ssh_key` — SSH 私钥路径
   - `remote_port` / `local_port` — 隧道端口映射
3. 启动：
   - 双击 `start.vbs`（无终端窗口）
   - 或直接 `pythonw main.py`

## 文件说明

| 文件 | 说明 |
|------|------|
| `main.py` | 主程序（GUI + 隧道逻辑） |
| `config.json` | 运行时配置（gitignored） |
| `config.json.example` | 配置模板 |
| `start.vbs` | VBS 启动器（无窗口） |
