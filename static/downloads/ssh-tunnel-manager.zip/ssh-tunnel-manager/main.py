#!/usr/bin/env python3
# 立即脱离控制台 — 必须放在所有 import 之前
import ctypes as _ct, sys as _sys
if "pythonw" not in _sys.executable.lower():
    try: _ct.windll.kernel32.FreeConsole()
    except: pass
"""
SSH Tunnel Manager v10 — 精美仪表盘版
Canvas渐变卡片 · 发光状态灯 · 脉冲动画 · 健康条 · 延迟曲线
"""
import atexit
import json
import logging
import os
import queue
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
from dataclasses import dataclass, asdict, field
from datetime import datetime, timedelta
from enum import Enum
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional, List, Tuple

import netifaces
import pystray
from PIL import Image, ImageDraw

SCRIPT_DIR = Path(__file__).parent
CONFIG_FILE = SCRIPT_DIR / "config.json"
LOG_FILE = SCRIPT_DIR / "tunnel.log"
STATS_FILE = SCRIPT_DIR / "stats.json"
MAX_LOG_LINES = 300

STARTUP_REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
STARTUP_REG_NAME = "SSH_Tunnel_Manager"

C = {
    "bg": "#0a0e14",
    "card": "#12171f",
    "card_active": "#182230",
    "border": "#1f2937",
    "text": "#e2e8f0",
    "text2": "#7c879d",
    "accent": "#4090ff",
    "green": "#2ea043",
    "red": "#da3633",
    "yellow": "#d2991d",
    "orange": "#db6d28",
    "purple": "#8b5cf6",
    "cyan": "#29c8cf",
    "teal": "#14b8a6",
    "input_bg": "#0d1117",
    "btn_bg": "#1a2233",
    "btn_hover": "#243044",
    "btn_active": "#4090ff",
    "log_bg": "#0a0e14",
    "glow_green": "#238636",
    "glow_red": "#b62324",
    "glow_blue": "#1f6feb",
}


# ============================================================
#   DATA MODELS
# ============================================================

@dataclass
class Config:
    ecs_host: str = "your-server-ip"
    ecs_port: int = 22
    ssh_user: str = "root"
    ssh_key: str = r"C:\Users\your-username\.ssh\id_ed25519"
    remote_port: int = 2222
    local_port: int = 22
    network_wait_seconds: int = 5
    reconnect_base_delay: int = 5
    reconnect_max_delay: int = 60
    health_check_interval: int = 10
    ip_check_interval: int = 300
    enable_notifications: bool = True
    enable_auto_start: bool = False
    enable_verification: bool = True
    start_minimized: bool = False
    latency_good: int = 60
    latency_ok: int = 150

    def save(self):
        try:
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(asdict(self), f, indent=2, ensure_ascii=False)
        except Exception: pass

    @classmethod
    def load(cls):
        if CONFIG_FILE.exists():
            try:
                data = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
                valid = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
                return cls(**valid)
            except Exception: pass
        cfg = cls()
        cfg.save()
        return cfg


@dataclass
class ConnectionStats:
    total_connections: int = 0
    total_disconnects: int = 0
    total_uptime_seconds: float = 0
    last_connected_at: Optional[str] = None
    last_disconnected_at: Optional[str] = None
    current_session_start: Optional[str] = None
    longest_session_seconds: float = 0
    connection_history: List[dict] = field(default_factory=list)
    total_bytes_rx: int = 0
    total_bytes_tx: int = 0
    disconnect_reasons: List[dict] = field(default_factory=list)

    def save(self):
        try:
            with open(STATS_FILE, 'w', encoding='utf-8') as f:
                json.dump(asdict(self), f, indent=2, ensure_ascii=False)
        except Exception: pass

    @classmethod
    def load(cls):
        if STATS_FILE.exists():
            try:
                data = json.loads(STATS_FILE.read_text(encoding='utf-8'))
                valid = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
                return cls(**valid)
            except Exception: pass
        return cls()

    def on_connect(self):
        now = datetime.now().isoformat()
        self.total_connections += 1
        self.last_connected_at = now
        self.current_session_start = now
        self.save()

    def on_disconnect(self, reason: str = ""):
        now = datetime.now().isoformat()
        self.total_disconnects += 1
        self.last_disconnected_at = now
        if self.current_session_start:
            start = datetime.fromisoformat(self.current_session_start)
            duration = (datetime.now() - start).total_seconds()
            self.total_uptime_seconds += duration
            if duration > self.longest_session_seconds:
                self.longest_session_seconds = duration
            self.connection_history.append({
                "start": self.current_session_start,
                "end": now, "duration": round(duration, 1), "reason": reason,
            })
            if len(self.connection_history) > 300:
                self.connection_history = self.connection_history[-300:]
            self.current_session_start = None
        self.disconnect_reasons.append({"time": now, "reason": reason})
        if len(self.disconnect_reasons) > 50:
            self.disconnect_reasons = self.disconnect_reasons[-50:]
        self.save()

    def get_current_session_duration(self) -> float:
        if self.current_session_start:
            return (datetime.now() - datetime.fromisoformat(self.current_session_start)).total_seconds()
        return 0

    def fmt_uptime(self) -> str:
        total = self.total_uptime_seconds + self.get_current_session_duration()
        h, r = divmod(int(total), 3600)
        m, s = divmod(r, 60)
        if h: return f"{h}h{m}m"
        if m: return f"{m}m{s}s"
        return f"{s}s"

    def fmt_longest(self) -> str:
        h, r = divmod(int(self.longest_session_seconds), 3600)
        m, s = divmod(r, 60)
        if h: return f"{h}h{m}m"
        if m: return f"{m}m{s}s"
        return f"{s}s"

    def fmt_traffic(self) -> str:
        total = self.total_bytes_rx + self.total_bytes_tx
        for unit in ["B", "KB", "MB", "GB"]:
            if total < 1024: return f"{total:.1f} {unit}"
            total /= 1024
        return f"{total:.1f} TB"

    def get_24h_timeline(self) -> List[Tuple[str, str]]:
        now = datetime.now()
        slots = []
        for h_offset in range(23, -1, -1):
            slot_start = now - timedelta(hours=h_offset + 1)
            slot_end = now - timedelta(hours=h_offset)
            label = slot_end.strftime("%H")
            connected = False
            for entry in self.connection_history:
                try:
                    s = datetime.fromisoformat(entry["start"])
                    e = datetime.fromisoformat(entry["end"])
                    if s < slot_end and e > slot_start:
                        connected = True; break
                except Exception: pass
            if self.current_session_start:
                try:
                    s = datetime.fromisoformat(self.current_session_start)
                    if s < slot_end: connected = True
                except Exception: pass
            slots.append((label, "connected" if connected else "disconnected"))
        return slots


# ============================================================
#   STATE
# ============================================================

class TunnelState(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    NETWORK_LOST = "network_lost"
    VERIFYING = "verifying"
    DIAGNOSING = "diagnosing"

STATE_COLORS = {
    TunnelState.DISCONNECTED: C["red"],
    TunnelState.CONNECTING: C["yellow"],
    TunnelState.CONNECTED: C["green"],
    TunnelState.NETWORK_LOST: C["text2"],
    TunnelState.VERIFYING: C["accent"],
    TunnelState.DIAGNOSING: C["purple"],
}
STATE_ICONS = {
    TunnelState.DISCONNECTED: "\u25cf",
    TunnelState.CONNECTING: "\u25d0",
    TunnelState.CONNECTED: "\u25cf",
    TunnelState.NETWORK_LOST: "\u25cb",
    TunnelState.VERIFYING: "\u25d1",
    TunnelState.DIAGNOSING: "\u25c9",
}
STATE_TEXTS = {
    TunnelState.DISCONNECTED: "未连接",
    TunnelState.CONNECTING: "连接中...",
    TunnelState.CONNECTED: "已连接",
    TunnelState.NETWORK_LOST: "网络断开",
    TunnelState.VERIFYING: "验证中...",
    TunnelState.DIAGNOSING: "诊断中...",
}


# ============================================================
#   LOGGER
# ============================================================

class LogManager:
    def __init__(self, log_file):
        self._cbs = []
        self._lock = threading.Lock()
        self._recent: List[str] = []
        self.logger = logging.getLogger("TM")
        self.logger.handlers.clear()
        self.logger.setLevel(logging.INFO)
        fh = RotatingFileHandler(str(log_file), maxBytes=5*1024*1024, backupCount=3, encoding='utf-8')
        fh.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', datefmt='%H:%M:%S'))
        self.logger.addHandler(fh)

    def add_cb(self, cb):
        with self._lock: self._cbs.append(cb)

    def remove_cb(self, cb):
        with self._lock:
            if cb in self._cbs: self._cbs.remove(cb)

    def _notify(self, entry):
        with self._lock:
            self._recent.append(entry)
            if len(self._recent) > 200: self._recent = self._recent[-200:]
            for cb in self._cbs[:]:
                try: cb(entry)
                except Exception: pass

    def info(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.logger.info(msg)
        self._notify(f"[{ts}]  {msg}")

    def warning(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.logger.warning(msg)
        self._notify(f"[{ts}] ! {msg}")

    def error(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.logger.error(msg)
        self._notify(f"[{ts}] X {msg}")

    def success(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.logger.info(msg)
        self._notify(f"[{ts}] OK {msg}")

    def get_recent(self, n: int = 50) -> List[str]:
        with self._lock: return list(self._recent[-n:])

log = LogManager(LOG_FILE)


# ============================================================
#   UTILITIES
# ============================================================

def has_network():
    try: return netifaces.gateways().get('default', {}).get(netifaces.AF_INET) is not None
    except Exception: return False

def get_default_gw():
    try: return netifaces.gateways().get('default', {}).get(netifaces.AF_INET)
    except Exception: return None

def make_ssh_tunnel_cmd(cfg: Config):
    return [
        "ssh", "-i", cfg.ssh_key,
        "-o", "ServerAliveInterval=3", "-o", "ServerAliveCountMax=10",
        "-o", "ConnectTimeout=8", "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=NUL", "-o", "ExitOnForwardFailure=yes",
        "-o", "TCPKeepAlive=yes", "-o", "Compression=yes", "-o", "IPQoS=throughput",
        "-N", "-R", f"{cfg.remote_port}:localhost:{cfg.local_port}",
        f"{cfg.ssh_user}@{cfg.ecs_host}"
    ]

def run_ssh_background(cmd):
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE
    return subprocess.Popen(cmd, startupinfo=si, stdout=subprocess.PIPE, stderr=subprocess.PIPE, errors='replace')

def kill_proc(proc):
    if proc and proc.poll() is None:
        try: proc.kill(); proc.wait(timeout=5)
        except Exception: pass

def cleanup_remote_port(cfg: Config) -> bool:
    cleanup_cmd = [
        "ssh", "-i", cfg.ssh_key, "-o", "ConnectTimeout=5",
        "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL",
        f"{cfg.ssh_user}@{cfg.ecs_host}",
        f"fuser -k {cfg.remote_port}/tcp 2>/dev/null; sleep 1; echo done"
    ]
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE
    try:
        result = subprocess.run(cleanup_cmd, capture_output=True, timeout=10, startupinfo=si, errors='replace')
        if "done" in result.stdout:
            log.info(f"cleaned remote port {cfg.remote_port}")
            time.sleep(2)
            return True
    except Exception as e: log.warning(f"port cleanup failed: {e}")
    return False

def measure_latency(host: str) -> Optional[float]:
    try:
        start = time.time()
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = subprocess.SW_HIDE
        result = subprocess.run(
            ["ssh", "-o", "ConnectTimeout=5", "-o", "StrictHostKeyChecking=no",
             "-o", "UserKnownHostsFile=NUL", f"root@{host}", "echo pong"],
            capture_output=True, timeout=8, startupinfo=si, errors='replace'
        )
        if result.returncode == 0: return round((time.time() - start) * 1000)
    except Exception: pass
    return None

def latency_to_grade(ms: Optional[float], cfg: Config) -> tuple:
    if ms is None: return ("?", C["text2"], "?")
    if ms < cfg.latency_good: return ("A", C["green"], "excellent")
    if ms < cfg.latency_ok: return ("B", C["yellow"], "good")
    if ms < 300: return ("C", C["orange"], "ok")
    return ("D", C["red"], "poor")

def health_score(latency_ms: Optional[float], uptime_ratio: float, cfg: Config) -> Tuple[int, str, str]:
    score = 0
    details = []
    if latency_ms is not None:
        if latency_ms < cfg.latency_good: score += 40; details.append("lat:excellent")
        elif latency_ms < cfg.latency_ok: score += 30; details.append("lat:good")
        elif latency_ms < 300: score += 15; details.append("lat:ok")
        else: details.append("lat:poor")
    else: details.append("lat:?")
    if uptime_ratio > 0.99: score += 40; details.append("up:99%+")
    elif uptime_ratio > 0.95: score += 30; details.append("up:95%+")
    elif uptime_ratio > 0.80: score += 20; details.append("up:80%+")
    elif uptime_ratio > 0: score += 10; details.append("up:low")
    else: details.append("up:no history")
    score += 10
    color = C["green"] if score >= 70 else (C["yellow"] if score >= 40 else C["red"])
    return score, color, " | ".join(details)

def analyze_disconnect_reason(ssh_error: str, proc_returncode: Optional[int] = None) -> str:
    if not ssh_error and proc_returncode is not None and proc_returncode != 0:
        return f"SSH exit({proc_returncode})"
    if "port forwarding failed" in ssh_error: return "port busy"
    if "Connection timed out" in ssh_error: return "timeout"
    if "Connection refused" in ssh_error: return "refused"
    if "Permission denied" in ssh_error or "publickey" in ssh_error: return "auth fail"
    if "Host key verification failed" in ssh_error: return "host key"
    if "Connection reset" in ssh_error: return "reset"
    if "Broken pipe" in ssh_error: return "broken pipe"
    if "No route to host" in ssh_error: return "no route"
    if "Name or service not known" in ssh_error or "Could not resolve" in ssh_error: return "DNS fail"
    if ssh_error.strip(): return f"err: {ssh_error.strip()[:60]}"
    return "disconnected"

def ssh_quick_exec(cfg: Config, command: str, timeout: int = 10) -> Optional[str]:
    try:
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = subprocess.SW_HIDE
        result = subprocess.run(
            ["ssh", "-i", cfg.ssh_key, "-o", "ConnectTimeout=5",
             "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL",
             f"{cfg.ssh_user}@{cfg.ecs_host}", command],
            capture_output=True, timeout=timeout, startupinfo=si, errors='replace'
        )
        if result.returncode == 0: return result.stdout.strip()
        return result.stderr.strip() if result.stderr else None
    except subprocess.TimeoutExpired: return "timeout"
    except Exception as e: return str(e)

def check_ssh_key(cfg: Config) -> Tuple[bool, str]:
    key_path = Path(cfg.ssh_key)
    if not key_path.exists(): return False, "key not found"
    if not key_path.is_file(): return False, "not a file"
    try:
        content = key_path.read_text()
        if "PRIVATE KEY" not in content: return False, "bad format"
    except Exception: return False, "cant read"
    return True, "ok"

def get_local_tcp_connections(port: int) -> int:
    try:
        result = subprocess.run(
            ["powershell", "-Command",
             f"(Get-NetTCPConnection -LocalPort {port} -ErrorAction SilentlyContinue | Measure-Object).Count"],
            capture_output=True, timeout=5, creationflags=subprocess.CREATE_NO_WINDOW, errors='replace'
        )
        return int(result.stdout.strip() or 0)
    except Exception: return 0


# ============================================================
#   NOTIFIER
# ============================================================

class Notifier:
    @staticmethod
    def send(title: str, message: str):
        try:
            ps = (
                "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null;"
                "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null;"
                "$t='<toast><visual><binding template=\"ToastGeneric\">"
                f"<text>{title}</text><text>{message}</text>"
                "</binding></visual>"
                "<audio src=\"ms-winsoundevent:Notification.Default\"/></toast>';"
                "$x=New-Object Windows.Data.Xml.Dom.XmlDocument;$x.LoadXml($t);"
                "$n=[Windows.UI.Notifications.ToastNotification]::new($x);"
                "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('SSH Tunnel Manager').Show($n)"
            )
            subprocess.run(["powershell", "-Command", ps],
                           capture_output=True, timeout=10,
                           creationflags=subprocess.CREATE_NO_WINDOW)
        except Exception: pass


# ============================================================
#   IP CHECKER
# ============================================================

class IPChecker:
    def __init__(self, config: Config, on_ip_changed):
        self.config = config
        self.on_ip_changed = on_ip_changed
        self._last_ip = config.ecs_host
        self._running = False

    def start(self):
        if self._running: return
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self): self._running = False

    def _get_ecs_public_ip(self) -> Optional[str]:
        try:
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
            result = subprocess.run(
                ["ssh", "-i", self.config.ssh_key, "-o", "ConnectTimeout=10",
                 "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL",
                 f"{self.config.ssh_user}@{self.config.ecs_host}", "curl -s ifconfig.me"],
                capture_output=True, timeout=15, startupinfo=si, errors='replace'
            )
            ip = result.stdout.strip()
            if ip and all(c.isdigit() or c == '.' for c in ip) and ip.count('.') == 3:
                return ip
        except Exception: pass
        return None

    def _loop(self):
        while self._running:
            time.sleep(self.config.ip_check_interval)
            if not self._running: break
            try:
                new_ip = self._get_ecs_public_ip()
                if new_ip and new_ip != self._last_ip:
                    log.info(f"IP changed: {self._last_ip} -> {new_ip}")
                    self._last_ip = new_ip
                    self.on_ip_changed(new_ip)
            except Exception as e: log.warning(f"IP check err: {e}")


# ============================================================
#   AUTOSTART
# ============================================================

class AutoStart:
    @staticmethod
    def is_enabled() -> bool:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_REG_KEY, 0, winreg.KEY_READ)
            try: winreg.QueryValueEx(key, STARTUP_REG_NAME); return True
            except FileNotFoundError: return False
            finally: winreg.CloseKey(key)
        except Exception: return False

    @staticmethod
    def enable():
        try:
            import winreg
            vbs_path = SCRIPT_DIR / "start_hidden.vbs"
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_REG_KEY, 0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(key, STARTUP_REG_NAME, 0, winreg.REG_SZ, f'wscript.exe "{vbs_path}"')
            winreg.CloseKey(key)
            log.success("autostart enabled")
            return True
        except Exception as e:
            log.error(f"autostart failed: {e}")
            return False

    @staticmethod
    def disable():
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_REG_KEY, 0, winreg.KEY_SET_VALUE)
            try: winreg.DeleteValue(key, STARTUP_REG_NAME)
            except FileNotFoundError: pass
            winreg.CloseKey(key)
            log.success("autostart disabled")
            return True
        except Exception as e:
            log.error(f"autostart disable failed: {e}")
            return False


# ============================================================
#   TUNNEL CORE
# ============================================================

class TunnelManager:
    def __init__(self, config: Config, stats: ConnectionStats, state_cb, notify_cb=None):
        self.config = config
        self.stats = stats
        self.state_cb = state_cb
        self.notify_cb = notify_cb
        self._proc = None
        self._state = TunnelState.DISCONNECTED
        self._running = False
        self._connected_since = None
        self._retry_count = 0
        self._retry_delay = config.reconnect_base_delay
        self._event = queue.Queue()
        self._last_latency: Optional[float] = None
        self._latency_history: List[float] = []
        self._was_connected = False
        self._last_disconnect_reason: str = ""
        self._local_connections: int = 0

    @property
    def state(self): return self._state

    @property
    def uptime(self):
        if self._state == TunnelState.CONNECTED and self._connected_since:
            s = int((datetime.now() - self._connected_since).total_seconds())
            h, r = divmod(s, 3600)
            m, sec = divmod(r, 60)
            if h: return f"{h}h{m}m{sec}s"
            if m: return f"{m}m{sec}s"
            return f"{sec}s"
        return None

    @property
    def latency(self): return self._last_latency
    @property
    def latency_history(self): return self._latency_history
    @property
    def retry_count(self): return self._retry_count
    @property
    def last_disconnect_reason(self): return self._last_disconnect_reason
    @property
    def local_connections(self): return self._local_connections

    @property
    def uptime_ratio(self) -> float:
        total = self.stats.total_uptime_seconds + self.stats.get_current_session_duration()
        return min(1.0, total / 86400) if total > 0 else 0

    def _set_state(self, new, reason: str = ""):
        if self._state == new: return
        old = self._state
        self._state = new
        if new == TunnelState.CONNECTED:
            self._connected_since = datetime.now()
            self._retry_count = 0
            self._retry_delay = self.config.reconnect_base_delay
            if not self._was_connected:
                self._was_connected = True
                self.stats.on_connect()
                if self.notify_cb and self.config.enable_notifications:
                    self.notify_cb("tunnel connected", self.config.ecs_host)
        elif old == TunnelState.CONNECTED:
            self._connected_since = None
            self._was_connected = False
            self._last_disconnect_reason = reason
            self.stats.on_disconnect(reason)
            if self.notify_cb and self.config.enable_notifications:
                self.notify_cb("tunnel disconnected", reason or "connection lost")
        log.info(f"{STATE_TEXTS.get(old,'?')} -> {STATE_TEXTS.get(new,'?')}")
        try: self.state_cb(new)
        except Exception: pass

    def _try_connect(self):
        proc = run_ssh_background(make_ssh_tunnel_cmd(self.config))
        start = time.time()
        while time.time() - start < 10:
            time.sleep(1)
            if proc.poll() is not None:
                err = ""
                try: err = proc.stderr.read() if proc.stderr else ""
                except Exception: pass
                if "port forwarding failed" in err: return None, True, err
                return None, False, err
        if proc.poll() is None: return proc, False, ""
        kill_proc(proc)
        return None, False, "unstable"

    def _verify_tunnel(self) -> bool:
        if not self.config.enable_verification: return True
        try:
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
            result = subprocess.run(
                ["ssh", "-o", "ConnectTimeout=5", "-o", "StrictHostKeyChecking=no",
                 "-o", "UserKnownHostsFile=NUL", "-i", self.config.ssh_key,
                 f"{self.config.ssh_user}@{self.config.ecs_host}",
                 f"ss -tlnp | grep :{self.config.remote_port}"],
                capture_output=True, timeout=10, startupinfo=si, errors='replace'
            )
            return f":{self.config.remote_port}" in result.stdout
        except Exception: return False

    def _do_connect(self):
        kill_proc(self._proc)
        self._proc = None
        self._set_state(TunnelState.CONNECTING)
        proc, port_busy, ssh_error = self._try_connect()
        if proc:
            self._proc = proc
            if self.config.enable_verification:
                self._set_state(TunnelState.VERIFYING)
                if self._verify_tunnel():
                    log.success("tunnel verified")
                    self._set_state(TunnelState.CONNECTED)
                    threading.Thread(target=self._measure_latency, daemon=True).start()
                    threading.Thread(target=self._measure_connections, daemon=True).start()
                    return True
                log.warning("verification failed, retry...")
                kill_proc(proc)
                self._proc = None
                self._set_state(TunnelState.DISCONNECTED, "verification failed")
                return False
            self._set_state(TunnelState.CONNECTED)
            threading.Thread(target=self._measure_latency, daemon=True).start()
            return True
        reason = analyze_disconnect_reason(ssh_error, proc.returncode if proc else None)
        if port_busy:
            if cleanup_remote_port(self.config):
                proc, _, ssh_error2 = self._try_connect()
                if proc:
                    self._proc = proc
                    self._set_state(TunnelState.CONNECTED)
                    threading.Thread(target=self._measure_latency, daemon=True).start()
                    return True
                reason = analyze_disconnect_reason(ssh_error2, None)
            else: reason = "port cleanup failed"
        self._set_state(TunnelState.DISCONNECTED, reason)
        return False

    def _measure_latency(self):
        lat = measure_latency(self.config.ecs_host)
        if lat is not None:
            self._last_latency = lat
            self._latency_history.append(lat)
            if len(self._latency_history) > 100: self._latency_history = self._latency_history[-100:]

    def _measure_connections(self):
        self._local_connections = get_local_tcp_connections(self.config.local_port)
        if self._local_connections > 0:
            self.stats.total_bytes_rx += self._local_connections * 128
            self.stats.total_bytes_tx += self._local_connections * 128
            self.stats.save()

    def _do_comprehensive_diagnosis(self) -> List[Tuple[str, bool, str]]:
        results = []
        if has_network(): results.append(("network", True, "ok"))
        else: results.append(("network", False, "no network")); return results
        try:
            import socket
            socket.getaddrinfo(self.config.ecs_host, None, socket.AF_INET)
            results.append(("DNS", True, "ok"))
        except Exception:
            results.append(("DNS", False, f"resolve fail")); return results
        ok, msg = check_ssh_key(self.config)
        results.append(("SSH key", ok, msg))
        if not ok: return results
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            rc = s.connect_ex((self.config.ecs_host, self.config.ecs_port))
            s.close()
            if rc == 0: results.append(("port", True, f":{self.config.ecs_port} open"))
            else: results.append(("port", False, f":{self.config.ecs_port} closed"))
        except Exception as e: results.append(("port", False, str(e)))
        lat = measure_latency(self.config.ecs_host)
        if lat is not None: results.append(("SSH login", True, f"{lat:.0f}ms"))
        else: results.append(("SSH login", False, "failed"))
        if self.state == TunnelState.CONNECTED:
            status = ssh_quick_exec(self.config, f"ss -tlnp | grep :{self.config.remote_port}", timeout=8)
            if status and f":{self.config.remote_port}" in status: results.append(("tunnel", True, "listening"))
            else: results.append(("tunnel", False, "not listening"))
        else: results.append(("tunnel", False, "not connected"))
        return results

    def comprehensive_diagnosis(self) -> List[Tuple[str, bool, str]]:
        results = []
        for item in self._do_comprehensive_diagnosis():
            results.append(item)
            status = "OK" if item[1] else "FAIL"
            log.info(f"diag [{status}] {item[0]}: {item[2]}")
        passed = sum(1 for _, ok, _ in results if ok)
        log.info(f"diag done: {passed}/{len(results)}")
        return results

    def _loop(self):
        last_check = 0
        while self._running:
            try:
                timeout = self.config.health_check_interval if self._state == TunnelState.CONNECTED else self._retry_delay
                try: ev = self._event.get(timeout=timeout)
                except queue.Empty: ev = None
                if ev == "stop": break
                if ev == "network_changed":
                    time.sleep(self.config.network_wait_seconds)
                    if not self._running: break
                now = time.time()
                if self._state == TunnelState.CONNECTED:
                    if now - last_check >= self.config.health_check_interval:
                        last_check = now
                        if self._proc and self._proc.poll() is not None:
                            err = ""
                            try: err = self._proc.stderr.read() if self._proc.stderr else ""
                            except Exception: pass
                            reason = analyze_disconnect_reason(err, self._proc.returncode)
                            log.warning(f"disconnected: {reason}")
                            kill_proc(self._proc)
                            self._proc = None
                            self._set_state(TunnelState.DISCONNECTED, reason)
                        else:
                            threading.Thread(target=self._measure_latency, daemon=True).start()
                            threading.Thread(target=self._measure_connections, daemon=True).start()
                    continue
                if not has_network():
                    self._set_state(TunnelState.NETWORK_LOST)
                    continue
                success = self._do_connect()
                if success:
                    last_check = time.time()
                    continue
                self._retry_delay = min(self._retry_delay * 2, self.config.reconnect_max_delay)
                self._retry_count += 1
                if self._retry_count <= 2:
                    log.info(f"retry #{self._retry_count} wait {self._retry_delay}s")
            except Exception as e:
                log.error(f"loop err: {e}")
                time.sleep(5)

    def on_network_change(self, has_net):
        if has_net:
            log.info("network restored")
            self._event.put("network_changed")
        else:
            log.info("network lost")
            kill_proc(self._proc)
            self._proc = None
            self._set_state(TunnelState.NETWORK_LOST)

    def on_ip_changed(self, new_ip: str):
        old_ip = self.config.ecs_host
        self.config.ecs_host = new_ip
        self.config.save()
        log.info(f"ip updated: {old_ip} -> {new_ip}")
        self.manual_reconnect()

    def start(self):
        if self._running: return
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()
        self._event.put("start")

    def stop(self):
        self._running = False
        self._event.put("stop")
        kill_proc(self._proc)
        self._proc = None

    def manual_reconnect(self):
        kill_proc(self._proc)
        self._proc = None
        self._set_state(TunnelState.DISCONNECTED)
        self._retry_delay = self.config.reconnect_base_delay
        self._retry_count = 0
        self._event.put("manual")


# ============================================================
#   UI COMPONENTS v10.1
# ============================================================

class DarkButton(tk.Frame):
    def __init__(self, parent, text, command, accent=False):
        super().__init__(parent, bg=C["bg"])
        bg = C["accent"] if accent else "#1a2332"
        fg = "#ffffff" if accent else "#b0bec5"
        hover = "#2979ff" if accent else "#263850"
        self.btn = tk.Label(self, text=text, bg=bg, fg=fg,
                            font=("Microsoft YaHei UI", 9), padx=14, pady=6,
                            cursor="hand2", relief="flat", borderwidth=0)
        self.btn.pack()
        self.btn.bind("<Button-1>", lambda e: command())
        self.btn.bind("<Enter>", lambda e: self.btn.config(bg=hover))
        self.btn.bind("<Leave>", lambda e: self.btn.config(bg=bg))


class ModernCard(tk.Canvas):
    def __init__(self, parent, width=148, height=88):
        super().__init__(parent, width=width, height=height,
                         bg=C["bg"], highlightthickness=0, bd=0)
        self.w = width
        self.h = height
        self._draw_bg()

    def _draw_bg(self):
        for i in range(self.h):
            ratio = i / self.h
            r = int(10 + ratio * 8)
            g = int(14 + ratio * 10)
            b = int(23 + ratio * 12)
            self.create_line(0, i, self.w, i, fill=f"#{r:02x}{g:02x}{b:02x}", width=1, tags="bg")
        self.create_rectangle(0, 0, self.w, 1, fill="#2a3a5c", outline="", tags="bg")
        self.create_rectangle(0, 0, self.w-1, self.h-1, outline="#1e2d3d", width=1, tags="bg")

    def set_content(self, label, value, color=None, sub=""):
        self.delete("content")
        self.create_text(12, 14, text=label, fill="#667788", font=("Microsoft YaHei UI", 8),
                         anchor=tk.W, tags="content")
        c = color or "#dde4ed"
        self.create_text(12, 46, text=value, fill=c, font=("Consolas", 16, "bold"),
                         anchor=tk.W, tags="content")
        if sub:
            self.create_text(12, 70, text=sub, fill="#556677", font=("Microsoft YaHei UI", 7),
                             anchor=tk.W, tags="content")


class GlowDot(tk.Canvas):
    def __init__(self, parent, size=32):
        super().__init__(parent, width=size, height=size,
                         bg=C["bg"], highlightthickness=0, bd=0)
        self.size = size
        self._color = C["red"]
        self._phase = 0

    def set_color(self, color):
        self._color = color

    def _draw(self):
        self.delete("all")
        cx = cy = self.size / 2
        r = self.size / 2 - 5
        glow_r = r + 3 + self._phase * 2
        alpha = hex(int(30 + self._phase * 12))[2:].zfill(2)
        self.create_oval(cx - glow_r, cy - glow_r, cx + glow_r, cy + glow_r,
                         fill="", outline=self._color, width=1)
        self.create_oval(cx - r, cy - r, cx + r, cy + r,
                         fill=self._color, outline="")

    def pulse(self):
        self._phase = (self._phase + 1) % 8
        self._draw()
        if self.winfo_exists():
            self.after(300, self.pulse)


class HealthBar(tk.Canvas):
    def __init__(self, parent, width=280, height=6):
        super().__init__(parent, width=width, height=height,
                         bg=C["bg"], highlightthickness=0, bd=0)
        self.w = width
        self.h = height
        self.create_rectangle(0, 0, width, height, fill="#1a2533", outline="")

    def set_value(self, pct, color):
        self.delete("bar")
        w = max(2, int(self.w * pct / 100))
        r0, g0, b0 = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
        for i in range(self.h):
            rr = min(255, int(r0 + (255 - r0) * i / self.h * 0.35))
            gg = min(255, int(g0 + (255 - g0) * i / self.h * 0.35))
            bb = min(255, int(b0 + (255 - b0) * i / self.h * 0.35))
            self.create_line(0, i, w, i, fill=f"#{rr:02x}{gg:02x}{bb:02x}", tags="bar")


class LatencySparkline(tk.Canvas):
    def __init__(self, parent, width=280, height=32):
        super().__init__(parent, width=width, height=height,
                         bg=C["bg"], highlightthickness=0, bd=0)

    def update(self, history):
        self.delete("all")
        if len(history) < 2: return
        w = self.winfo_width() or 280
        h = 32
        pad = 2
        vals = history[-40:]
        mx = max(max(vals), 100)
        mn = min(vals)
        rng = max(mx - mn, 1)
        pts = []
        for i, v in enumerate(vals):
            x = pad + (i / max(len(vals) - 1, 1)) * (w - pad * 2)
            y = h - pad - ((v - mn) / rng) * (h - pad * 2)
            pts.extend([x, y])
        for i in range(0, len(pts) - 3, 2):
            self.create_line(pts[i], pts[i+1], pts[i+2], pts[i+3],
                             fill=C["accent"], width=1.2)


# ============================================================
#   设置窗口
# ============================================================

class ConfigEditor:
    def __init__(self, parent, config: Config, on_save):
        self.config = config
        self.on_save = on_save
        self.window = tk.Toplevel(parent)
        self.window.title("设置")
        self.window.geometry("520x780")
        self.window.resizable(False, False)
        self.window.transient(parent)
        self.window.grab_set()
        self.window.configure(bg=C["bg"])
        self._center()
        self._build_ui()

    def _center(self):
        self.window.update_idletasks()
        w, h = self.window.winfo_width(), self.window.winfo_height()
        sw, sh = self.window.winfo_screenwidth(), self.window.winfo_screenheight()
        self.window.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")

    def _entry(self, parent, label, attr, row):
        tk.Label(parent, text=label, fg=C["text"], bg=C["card"],
                 font=("Microsoft YaHei UI", 9)).grid(row=row, column=0, sticky=tk.W, pady=2)
        e = tk.Entry(parent, bg=C["input_bg"], fg=C["text"], insertbackground=C["text"],
                     relief=tk.FLAT, font=("Consolas", 9), borderwidth=0, highlightthickness=1,
                     highlightbackground=C["border"], highlightcolor=C["accent"])
        e.insert(0, str(getattr(self.config, attr)))
        e.grid(row=row, column=1, sticky=tk.EW, pady=2, padx=(8, 0), ipady=2)
        return e

    def _section(self, parent, title, fields):
        f = tk.LabelFrame(parent, text=f" {title} ", bg=C["card"], fg=C["text"],
                          font=("Microsoft YaHei UI", 10, "bold"),
                          relief=tk.FLAT, padx=12, pady=8,
                          highlightthickness=1, highlightbackground=C["border"])
        f.pack(fill=tk.X, pady=(0, 8))
        f.columnconfigure(1, weight=1)
        for i, (lbl, attr) in enumerate(fields):
            self._entries[attr] = self._entry(f, lbl, attr, i)

    def _build_ui(self):
        main = tk.Frame(self.window, bg=C["bg"], padx=16, pady=10)
        main.pack(fill=tk.BOTH, expand=True)

        self._entries = {}

        self._section(main, "连接设置", [
            ("ECS 地址", "ecs_host"), ("SSH 端口", "ecs_port"),
            ("SSH 用户", "ssh_user"), ("密钥路径", "ssh_key"),
            ("远程端口", "remote_port"), ("本地端口", "local_port"),
        ])

        self._section(main, "重连与检测", [
            ("基础延迟(秒)", "reconnect_base_delay"),
            ("最大延迟(秒)", "reconnect_max_delay"),
            ("健康检查(秒)", "health_check_interval"),
            ("IP 检测(秒)", "ip_check_interval"),
            ("优秀延迟 < ms", "latency_good"),
            ("良好延迟 < ms", "latency_ok"),
        ])

        opts = tk.LabelFrame(main, text=" 功能开关 ", bg=C["card"], fg=C["text"],
                             font=("Microsoft YaHei UI", 10, "bold"),
                             relief=tk.FLAT, padx=12, pady=8,
                             highlightthickness=1, highlightbackground=C["border"])
        opts.pack(fill=tk.X, pady=(0, 10))

        self._nv = tk.BooleanVar(value=self.config.enable_notifications)
        self._vv = tk.BooleanVar(value=self.config.enable_verification)
        self._av = tk.BooleanVar(value=AutoStart.is_enabled())
        self._mv = tk.BooleanVar(value=self.config.start_minimized)

        for txt, var in [
            ("桌面通知", self._nv), ("连接验证", self._vv),
            ("开机自启", self._av), ("启动最小化", self._mv),
        ]:
            tk.Checkbutton(opts, text=txt, variable=var, bg=C["card"], fg=C["text"],
                           selectcolor=C["btn_bg"], activebackground=C["card"],
                           activeforeground=C["accent"], font=("Microsoft YaHei UI", 9),
                           relief=tk.FLAT).pack(anchor=tk.W, pady=1)

        # 按钮区
        btns = tk.Frame(main, bg=C["bg"])
        btns.pack(fill=tk.X, pady=(4, 0))
        DarkButton(btns, "取消", self.window.destroy).pack(side=tk.RIGHT, padx=(6, 0))
        DarkButton(btns, "保存设置", self._save, accent=True).pack(side=tk.RIGHT)

    def _save(self):
        try:
            for attr, entry in self._entries.items():
                val = entry.get().strip()
                tp = type(getattr(self.config, attr))
                setattr(self.config, attr, tp(val))
            self.config.enable_notifications = self._nv.get()
            self.config.enable_verification = self._vv.get()
            self.config.start_minimized = self._mv.get()
            if self._av.get(): AutoStart.enable()
            else: AutoStart.disable()
            self.config.save()
            self.on_save()
            messagebox.showinfo("完成", "配置已保存")
            self.window.destroy()
        except Exception as e:
            messagebox.showerror("错误", f"保存失败: {e}")


# ============================================================
#   诊断窗口
# ============================================================

class DiagnosisWindow:
    def __init__(self, parent, config: Config, tunnel: TunnelManager):
        self.config = config
        self.tunnel = tunnel
        self.window = tk.Toplevel(parent)
        self.window.title("综合诊断")
        self.window.geometry("450x420")
        self.window.resizable(False, False)
        self.window.transient(parent)
        self.window.configure(bg=C["bg"])
        self._center()
        self._build_ui()
        self._run()

    def _center(self):
        self.window.update_idletasks()
        w, h = self.window.winfo_width(), self.window.winfo_height()
        sw, sh = self.window.winfo_screenwidth(), self.window.winfo_screenheight()
        self.window.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")

    def _build_ui(self):
        main = tk.Frame(self.window, bg=C["bg"], padx=16, pady=12)
        main.pack(fill=tk.BOTH, expand=True)
        tk.Label(main, text="综合诊断", fg=C["text"], bg=C["bg"],
                 font=("Microsoft YaHei UI", 14, "bold")).pack(anchor=tk.W, pady=(0, 4))
        tk.Label(main, text=f"目标: {self.config.ecs_host}:{self.config.remote_port}",
                 fg=C["text2"], bg=C["bg"], font=("Consolas", 9)).pack(anchor=tk.W, pady=(0, 10))
        self._list = tk.Frame(main, bg=C["bg"])
        self._list.pack(fill=tk.BOTH, expand=True)
        self._progress = tk.Label(main, text="诊断中...", fg=C["accent"], bg=C["bg"],
                                  font=("Microsoft YaHei UI", 10))
        self._progress.pack(pady=(8, 4))
        DarkButton(main, "关闭", self.window.destroy).pack()

    def _run(self):
        threading.Thread(target=self._do, daemon=True).start()

    def _do(self):
        results = self.tunnel.comprehensive_diagnosis()
        self.window.after(0, self._show, results)

    def _show(self, results):
        for w in self._list.winfo_children(): w.destroy()
        passed = sum(1 for _, ok, _ in results if ok)
        total = len(results)
        color = C["green"] if passed == total else (C["yellow"] if passed > 0 else C["red"])
        self._progress.config(text=f"{passed}/{total} 项通过", fg=color)

        cn_names = {"network": "网络连接", "DNS": "DNS 解析", "SSH key": "SSH 密钥",
                    "port": "端口连通", "SSH login": "SSH 登录", "tunnel": "隧道端口"}
        for name, ok, detail in results:
            cn = cn_names.get(name, name)
            bg = "#141e2b" if ok else "#1e1417"
            bd = "#1e3340" if ok else "#401e1e"
            row = tk.Frame(self._list, bg=bg, highlightthickness=1, highlightbackground=bd)
            row.pack(fill=tk.X, pady=2, ipady=6, padx=2)
            tk.Label(row, text=f"{'✓' if ok else '✕'} {cn}",
                     fg=C["green"] if ok else C["red"], bg=bg,
                     font=("Microsoft YaHei UI", 9, "bold")).pack(side=tk.LEFT, padx=10)
            tk.Label(row, text=detail, fg=C["text2"], bg=bg,
                     font=("Consolas", 8)).pack(side=tk.RIGHT, padx=10)


# ============================================================
#   统计窗口
# ============================================================

class StatsWindow:
    def __init__(self, parent, stats: ConnectionStats, tunnel: TunnelManager):
        self.stats = stats
        self.tunnel = tunnel
        self.window = tk.Toplevel(parent)
        self.window.title("连接统计")
        self.window.geometry("500x620")
        self.window.minsize(420, 500)
        self.window.transient(parent)
        self.window.configure(bg=C["bg"])
        self._center()
        self._build_ui()
        self._update()

    def _center(self):
        self.window.update_idletasks()
        w, h = self.window.winfo_width(), self.window.winfo_height()
        sw, sh = self.window.winfo_screenwidth(), self.window.winfo_screenheight()
        self.window.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")

    def _section(self, parent, title):
        f = tk.LabelFrame(parent, text=f" {title} ", bg=C["card"], fg=C["text"],
                          font=("Microsoft YaHei UI", 10, "bold"),
                          relief=tk.FLAT, padx=14, pady=10,
                          highlightthickness=1, highlightbackground=C["border"])
        f.pack(fill=tk.X, pady=(0, 8))
        return f

    def _row(self, parent, label):
        r = tk.Frame(parent, bg=C["card"])
        r.pack(fill=tk.X, pady=1)
        tk.Label(r, text=label, fg=C["text2"], bg=C["card"],
                 font=("Microsoft YaHei UI", 9)).pack(side=tk.LEFT)
        v = tk.Label(r, text="--", fg=C["text"], bg=C["card"],
                     font=("Consolas", 10, "bold"))
        v.pack(side=tk.RIGHT)
        return v

    def _build_ui(self):
        main = tk.Frame(self.window, bg=C["bg"], padx=18, pady=12)
        main.pack(fill=tk.BOTH, expand=True)

        s = self._section(main, "当前状态")
        self._sv = self._row(s, "状态")
        self._uv = self._row(s, "本次在线")
        self._lv = self._row(s, "延迟")
        self._hv = self._row(s, "健康评分")

        s2 = self._section(main, "历史统计")
        self._cv = self._row(s2, "总连接次数")
        self._dv = self._row(s2, "总断开次数")
        self._utv = self._row(s2, "累计在线")
        self._lov = self._row(s2, "最长单次")
        self._avv = self._row(s2, "平均连接")

        s3 = self._section(main, "流量统计")
        self._tv = self._row(s3, "累计流量")

        cf = self._section(main, "延迟趋势 (最近30次)")
        self._chart = tk.Canvas(cf, height=60, bg=C["card"], highlightthickness=0)
        self._chart.pack(fill=tk.X)

        tf = self._section(main, "24小时时间线")
        self._tl = tk.Canvas(tf, height=30, bg=C["card"], highlightthickness=0)
        self._tl.pack(fill=tk.X)

    def _draw_tl(self):
        self._tl.delete("all")
        w = self._tl.winfo_width() or 450
        slots = self.stats.get_24h_timeline()
        if not slots: return
        bw = w / len(slots)
        for i, (label, status) in enumerate(slots):
            x = i * bw
            c = C["green"] if status == "connected" else "#152028"
            self._tl.create_rectangle(x, 4, x + bw - 1, 26, fill=c, outline="")
            if i % 4 == 0:
                self._tl.create_text(x + bw / 2, 15, text=label, fill=C["text2"], font=("Consolas", 7))

    def _draw_chart(self):
        self._chart.delete("all")
        hist = self.tunnel.latency_history[-30:]
        if len(hist) < 2: return
        w, h = self._chart.winfo_width() or 450, 60
        pad = 5
        cw, ch = w - pad * 2, h - pad * 2
        mx, mn = max(max(hist), 300), min(hist)
        pts = []
        for i, v in enumerate(hist):
            pts.extend([pad + (i / max(len(hist) - 1, 1)) * cw,
                        pad + ch - ((v - mn) / max(mx - mn, 1)) * ch])
        for i in range(0, len(pts) - 3, 2):
            self._chart.create_line(pts[i], pts[i+1], pts[i+2], pts[i+3],
                                    fill=C["accent"], width=1.5)
        self._chart.create_line(pad, pad + ch * 0.35, pad + cw, pad + ch * 0.35,
                                fill=C["border"], dash=(4, 4))

    def _update(self):
        try:
            self._sv.config(text=STATE_TEXTS.get(self.tunnel.state, "?"))
            self._uv.config(text=self.tunnel.uptime or "--")
            lat = self.tunnel.latency
            self._lv.config(text=f"{lat:.0f}ms" if lat else "--")
            sc, cl, _ = health_score(lat, self.tunnel.uptime_ratio, self.tunnel.config)
            self._hv.config(text=f"{sc}/100", fg=cl)
            self._cv.config(text=str(self.stats.total_connections))
            self._dv.config(text=str(self.stats.total_disconnects))
            self._utv.config(text=self.stats.fmt_uptime())
            self._lov.config(text=self.stats.fmt_longest())
            if self.stats.total_connections > 0:
                m, s = divmod(int(self.stats.total_uptime_seconds / max(1, self.stats.total_connections)), 60)
                self._avv.config(text=f"{m}分{s}秒")
            self._tv.config(text=self.stats.fmt_traffic())
            self._draw_chart()
            self._draw_tl()
        except Exception: pass
        if self.window.winfo_exists():
            self.window.after(3000, self._update)


# ============================================================
#   托盘图标
# ============================================================

class TrayIcon:
    def __init__(self, config, tunnel, show_cb, quit_cb):
        self.config = config
        self.tunnel = tunnel
        self.show_cb = show_cb
        self.quit_cb = quit_cb
        self._icon = None
        self._state = TunnelState.DISCONNECTED

    def _img(self, state):
        img = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        c = STATE_COLORS[state]
        d.ellipse([4, 4, 60, 60], fill=(0, 0, 0, 40))
        d.ellipse([6, 6, 58, 58], fill=c, outline=(255, 255, 255, 180), width=2)
        if state == TunnelState.CONNECTED:
            d.line([(22, 34), (28, 42), (42, 22)], fill='white', width=4)
        elif state == TunnelState.CONNECTING:
            d.arc([16, 16, 48, 48], 0, 270, fill='white', width=3)
            d.polygon([(44, 14), (50, 22), (40, 22)], fill='white')
        elif state == TunnelState.DISCONNECTED:
            d.line([(24, 24), (40, 40)], fill='white', width=4)
            d.line([(40, 24), (24, 40)], fill='white', width=4)
        elif state == TunnelState.VERIFYING:
            d.arc([16, 16, 48, 48], 0, 320, fill='white', width=3)
        else:
            d.line([(32, 18), (32, 38)], fill='white', width=4)
            d.ellipse([28, 44, 36, 52], fill='white')
        return img

    def _menu(self):
        ut = self.tunnel.uptime
        lat = self.tunnel.latency
        items = [
            pystray.MenuItem(f"状态: {STATE_TEXTS.get(self._state, '?')}", None, enabled=False),
            pystray.MenuItem(f"目标: {self.config.ecs_host}:{self.config.remote_port}", None, enabled=False),
        ]
        if ut: items.append(pystray.MenuItem(f"在线: {ut}", None, enabled=False))
        if lat is not None:
            g, _, _ = latency_to_grade(lat, self.config)
            items.append(pystray.MenuItem(f"延迟: {lat:.0f}ms [{g}]", None, enabled=False))
        items += [
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("显示窗口", lambda: self.show_cb(), default=True),
            pystray.MenuItem("手动重连", lambda: self.tunnel.manual_reconnect()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("退出", lambda: self.quit_cb()),
        ]
        return pystray.Menu(*items)

    def update(self, state):
        self._state = state
        if self._icon:
            try:
                self._icon.icon = self._img(state)
                self._icon.title = f"SSH隧道 - {STATE_TEXTS.get(state, '?')}"
                self._icon.menu = self._menu()
            except Exception: pass

    def refresh(self):
        if self._icon:
            try: self._icon.menu = self._menu()
            except Exception: pass

    def run(self):
        self._icon = pystray.Icon("SSH Tunnel", self._img(self._state),
                                  "SSH 隧道管理器", self._menu())
        threading.Thread(target=self._icon.run, daemon=True).start()


# ============================================================
#   ECS 快速操作
# ============================================================

class EcsQuickWindow:
    def __init__(self, parent, config: Config, tunnel: TunnelManager):
        self.config = config
        self.tunnel = tunnel
        self.window = tk.Toplevel(parent)
        self.window.title("ECS 快速操作")
        self.window.geometry("460x420")
        self.window.resizable(False, False)
        self.window.transient(parent)
        self.window.configure(bg=C["bg"])
        self._center()
        self._build_ui()

    def _center(self):
        self.window.update_idletasks()
        w, h = self.window.winfo_width(), self.window.winfo_height()
        sw, sh = self.window.winfo_screenwidth(), self.window.winfo_screenheight()
        self.window.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")

    def _build_ui(self):
        main = tk.Frame(self.window, bg=C["bg"], padx=16, pady=12)
        main.pack(fill=tk.BOTH, expand=True)
        tk.Label(main, text=f"目标: {self.config.ecs_host}", fg=C["accent"], bg=C["bg"],
                 font=("Consolas", 12, "bold")).pack(anchor=tk.W, pady=(0, 8))
        af = tk.LabelFrame(main, text=" 快捷操作 ", bg=C["card"], fg=C["text"],
                           font=("Microsoft YaHei UI", 10, "bold"),
                           relief=tk.FLAT, padx=10, pady=8,
                           highlightthickness=1, highlightbackground=C["border"])
        af.pack(fill=tk.X, pady=(0, 8))
        for label, cmd in [
            ("SSH 登录", f'start wt ssh -i "{self.config.ssh_key}" {self.config.ssh_user}@{self.config.ecs_host}'),
            ("系统负载", "uptime"), ("磁盘使用", "df -h / | tail -1"),
            ("内存使用", "free -h | grep -E '^Mem|total'"),
            ("端口监听", "ss -tlnp | head -15"),
            ("隧道状态", f"ss -tlnp | grep :{self.config.remote_port}"),
        ]:
            row = tk.Frame(af, bg=C["card"])
            row.pack(fill=tk.X, pady=1)
            DarkButton(row, label, lambda c=cmd, l=label: self._run(c, l)).pack(side=tk.LEFT)
        of = tk.LabelFrame(main, text=" 输出 ", bg=C["card"], fg=C["text"],
                           font=("Microsoft YaHei UI", 10, "bold"),
                           relief=tk.FLAT, padx=8, pady=6,
                           highlightthickness=1, highlightbackground=C["border"])
        of.pack(fill=tk.BOTH, expand=True)
        self._out = scrolledtext.ScrolledText(of, height=8, font=("Consolas", 9),
                                               bg=C["log_bg"], fg=C["text"],
                                               relief=tk.FLAT, state=tk.DISABLED)
        self._out.pack(fill=tk.BOTH, expand=True)

    def _run(self, cmd, label):
        self._out.config(state=tk.NORMAL)
        self._out.delete("1.0", tk.END)
        self._out.insert(tk.END, f"> {label}\n{'─'*40}\n")
        if cmd.startswith("start "):
            try:
                subprocess.Popen(cmd[6:], shell=True)
                self._out.insert(tk.END, "终端已打开\n")
            except Exception as e:
                self._out.insert(tk.END, f"错误: {e}\n")
        else:
            r = ssh_quick_exec(self.config, cmd, timeout=15)
            self._out.insert(tk.END, r or "(无输出)")
        self._out.config(state=tk.DISABLED)

# ============================================================
#   主窗口 v10.1
# ============================================================

class App:
    def __init__(self, config: Config, stats: ConnectionStats):
        self.config = config
        self.stats = stats
        self._closing = False
        self.root = tk.Tk()
        self.root.title("SSH 隧道管理器 v10")
        self.root.geometry("720x660")
        self.root.minsize(620, 560)
        self.root.configure(bg=C["bg"])
        self.root.protocol("WM_DELETE_WINDOW", self._hide)
        self.tunnel = TunnelManager(config, stats, self._on_state, self._on_notify)
        self.ip_checker = IPChecker(config, self.tunnel.on_ip_changed)
        self.tray = TrayIcon(config, self.tunnel, self._show, self._quit)
        self._build_ui()
        log.add_cb(self._log_cb)
        self._center()
        self._uptime_tick()
        self._bind_keys()

    def _center(self):
        w, h = 720, 660
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")

    def _bind_keys(self):
        self.root.bind("<Control-r>", lambda e: self.tunnel.manual_reconnect())
        self.root.bind("<Control-d>", lambda e: self._show_diagnosis())
        self.root.bind("<Control-s>", lambda e: self._show_settings())
        self.root.bind("<Control-f>", lambda e: self._search_entry.focus_set())

    def _on_notify(self, title, message): Notifier.send(title, message)

    def _build_ui(self):
        # 顶栏
        tb = tk.Frame(self.root, bg="#0c1622", height=40)
        tb.pack(fill=tk.X)
        tb.pack_propagate(False)
        tk.Label(tb, text=" SSH 隧道管理器", fg="#8899aa", bg="#0c1622",
                 font=("Microsoft YaHei UI", 11, "bold")).pack(side=tk.LEFT, padx=14, pady=8)
        self._info_lbl = tk.Label(tb, text="就绪", fg=C["text2"], bg="#0c1622",
                                  font=("Microsoft YaHei UI", 9))
        self._info_lbl.pack(side=tk.RIGHT, padx=14, pady=8)
        self._retry_lbl = tk.Label(tb, text="", fg=C["yellow"], bg="#0c1622",
                                   font=("Microsoft YaHei UI", 8))
        self._retry_lbl.pack(side=tk.RIGHT, pady=8)
        self._reason_lbl = tk.Label(tb, text="", fg=C["red"], bg="#0c1622",
                                    font=("Microsoft YaHei UI", 8))
        self._reason_lbl.pack(side=tk.RIGHT, padx=(0, 6), pady=8)

        main = tk.Frame(self.root, bg=C["bg"], padx=16, pady=10)
        main.pack(fill=tk.BOTH, expand=True)

        # 仪表盘
        dash = tk.Frame(main, bg=C["bg"])
        dash.pack(fill=tk.X, pady=(0, 10))

        left = tk.Frame(dash, bg=C["bg"])
        left.pack(side=tk.LEFT)
        self._glow = GlowDot(left, 32)
        self._glow.pack(side=tk.LEFT, padx=(0, 10))
        col = tk.Frame(left, bg=C["bg"])
        col.pack(side=tk.LEFT)
        self._state_lbl = tk.Label(col, text="未连接", fg=C["red"], bg=C["bg"],
                                   font=("Microsoft YaHei UI", 16, "bold"))
        self._state_lbl.pack(anchor=tk.W)
        self._target_lbl = tk.Label(col, text=f"{self.config.ecs_host}:{self.config.remote_port}",
                                    fg=C["text2"], bg=C["bg"], font=("Consolas", 9))
        self._target_lbl.pack(anchor=tk.W)

        cr = tk.Frame(dash, bg=C["bg"])
        cr.pack(side=tk.RIGHT)
        self._card_lat = ModernCard(cr, 148, 82)
        self._card_lat.pack(side=tk.LEFT, padx=3)
        self._card_upt = ModernCard(cr, 148, 82)
        self._card_upt.pack(side=tk.LEFT, padx=3)
        self._card_con = ModernCard(cr, 148, 82)
        self._card_con.pack(side=tk.LEFT, padx=3)
        self._card_hlt = ModernCard(cr, 148, 82)
        self._card_hlt.pack(side=tk.LEFT, padx=3)

        # 健康条 + 曲线
        hr = tk.Frame(main, bg=C["bg"])
        hr.pack(fill=tk.X, pady=(0, 8))
        tk.Label(hr, text="健康度", fg="#556677", bg=C["bg"],
                 font=("Microsoft YaHei UI", 8)).pack(side=tk.LEFT, padx=(0, 6))
        self._health_bar = HealthBar(hr, 280, 6)
        self._health_bar.pack(side=tk.LEFT)
        self._sparkline = LatencySparkline(hr, 280, 32)
        self._sparkline.pack(side=tk.RIGHT)

        # 按钮
        br = tk.Frame(main, bg=C["bg"])
        br.pack(fill=tk.X, pady=(0, 8))
        for t, cmd in [
            ("重连", self.tunnel.manual_reconnect),
            ("诊断", self._show_diagnosis),
            ("统计", self._show_stats),
            ("ECS", self._show_ecs),
            ("设置", self._show_settings),
        ]:
            DarkButton(br, t, cmd).pack(side=tk.LEFT, padx=(0, 3))
        rb = tk.Frame(br, bg=C["bg"])
        rb.pack(side=tk.RIGHT)
        DarkButton(rb, "复制", self._copy_ip).pack(side=tk.LEFT, padx=(0, 3))
        DarkButton(rb, "日志", lambda: os.startfile(str(LOG_FILE))).pack(side=tk.LEFT, padx=(0, 3))
        DarkButton(rb, "导出", self._export_log).pack(side=tk.LEFT)

        # 搜索
        sb = tk.Frame(main, bg=C["bg"])
        sb.pack(fill=tk.X, pady=(0, 3))
        tk.Label(sb, text="搜索", fg=C["text2"], bg=C["bg"],
                 font=("Microsoft YaHei UI", 8)).pack(side=tk.LEFT, padx=(0, 5))
        self._search_var = tk.StringVar()
        self._search_entry = tk.Entry(sb, textvariable=self._search_var, bg=C["input_bg"], fg=C["text"],
                                      insertbackground=C["text"], relief=tk.FLAT, font=("Consolas", 9),
                                      highlightthickness=1, highlightbackground=C["border"],
                                      highlightcolor=C["accent"])
        self._search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=2)
        self._search_entry.bind("<KeyRelease>", lambda e: self._filter_log())

        # 日志
        lf = tk.LabelFrame(main, text=" 运行日志 ", bg=C["card"], fg=C["text"],
                           font=("Microsoft YaHei UI", 9, "bold"),
                           relief=tk.FLAT, padx=5, pady=3,
                           highlightthickness=1, highlightbackground=C["border"])
        lf.pack(fill=tk.BOTH, expand=True)
        self._log = scrolledtext.ScrolledText(lf, font=("Consolas", 9),
                                               bg=C["log_bg"], fg=C["text"],
                                               relief=tk.FLAT, state=tk.DISABLED,
                                               insertbackground=C["text"])
        self._log.pack(fill=tk.BOTH, expand=True)
        for tag, fg in [("info", C["text2"]), ("warn", C["yellow"]), ("error", C["red"]),
                        ("success", C["green"]), ("verify", C["accent"])]:
            self._log.tag_configure(tag, foreground=fg)
        self._log_all_entries = []
        self._glow.pulse()

    def _copy_ip(self):
        text = f"{self.config.ecs_host}:{self.config.remote_port}"
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        log.success(f"已复制: {text}")

    def _show_diagnosis(self): DiagnosisWindow(self.root, self.config, self.tunnel)
    def _show_stats(self): StatsWindow(self.root, self.stats, self.tunnel)
    def _show_ecs(self): EcsQuickWindow(self.root, self.config, self.tunnel)

    def _show_settings(self):
        def cb(): self._target_lbl.config(text=f"{self.config.ecs_host}:{self.config.remote_port}")
        ConfigEditor(self.root, self.config, cb)

    def _export_log(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", filetypes=[("文本", "*.txt")],
            initialfile=f"tunnel_{datetime.now().strftime('%Y%m%d_%H%M')}.txt")
        if path:
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write("\n".join(self._log_all_entries))
                log.success(f"已导出: {path}")
            except Exception as e:
                log.error(f"导出失败: {e}")

    def _filter_log(self):
        q = self._search_var.get().lower().strip()
        self._log.config(state=tk.NORMAL)
        self._log.delete("1.0", tk.END)
        for entry in self._log_all_entries:
            if not q or q in entry.lower():
                tag = "info"
                lo = entry.lower()
                if any(w in lo for w in ["ok", "✓", "已验证", "已连接"]): tag = "success"
                elif "!" in entry or "⚠" in entry: tag = "warn"
                elif any(w in lo for w in ["x", "✕", "失败", "超时", "拒绝", "断开"]): tag = "error"
                elif "验证" in lo: tag = "verify"
                self._log.insert(tk.END, entry + "\n", tag)
        if not q: self._log.see(tk.END)
        self._log.config(state=tk.DISABLED)

    def _uptime_tick(self):
        if self._closing: return
        try:
            state = self.tunnel.state
            sc = STATE_COLORS.get(state, C["text2"])
            st = STATE_TEXTS.get(state, "?")
            self._state_lbl.config(text=st, fg=sc)
            self._glow.set_color(sc)

            if state == TunnelState.CONNECTED:
                self._info_lbl.config(text=f"已连接 {self.config.ecs_host}", fg=C["green"])
            elif state == TunnelState.CONNECTING:
                self._info_lbl.config(text="连接中...", fg=C["yellow"])
            elif state == TunnelState.VERIFYING:
                self._info_lbl.config(text="验证中...", fg=C["accent"])
            elif state == TunnelState.NETWORK_LOST:
                self._info_lbl.config(text="网络断开", fg=C["text2"])
            else:
                self._info_lbl.config(text="已断开", fg=C["red"])

            rc = self.tunnel.retry_count
            self._retry_lbl.config(text=f"重试×{rc}" if rc and state != TunnelState.CONNECTED else "")
            reason = self.tunnel.last_disconnect_reason
            self._reason_lbl.config(text=reason[:40] if reason and state == TunnelState.DISCONNECTED else "")

            lat = self.tunnel.latency
            if lat is not None:
                g, gc, _ = latency_to_grade(lat, self.config)
                self._card_lat.set_content("延迟", f"{lat:.0f}ms", gc, f"评级 {g}")
            else:
                self._card_lat.set_content("延迟", "--", C["text2"])
            self._card_upt.set_content("在线", self.tunnel.uptime or "--")
            conn = self.tunnel.local_connections
            self._card_con.set_content("连接数", str(conn), C["cyan"] if conn > 0 else C["text2"])
            hsc, hcl, _ = health_score(lat, self.tunnel.uptime_ratio, self.config)
            self._card_hlt.set_content("健康", f"{hsc}", hcl)
            self._health_bar.set_value(hsc, hcl)
            self._sparkline.update(self.tunnel.latency_history)
            self.tray.refresh()
        except Exception: pass
        self.root.after(2000, self._uptime_tick)

    def _log_cb(self, entry):
        if self._closing: return
        self._log_all_entries.append(entry)
        if len(self._log_all_entries) > MAX_LOG_LINES * 3:
            self._log_all_entries = self._log_all_entries[-MAX_LOG_LINES * 2:]
        self.root.after(0, self._append_log, entry)

    def _append_log(self, entry):
        if self._closing: return
        try:
            q = self._search_var.get().lower().strip()
            if q and q not in entry.lower(): return
            self._log.config(state=tk.NORMAL)
            tag = "info"
            lo = entry.lower()
            if any(w in lo for w in ["ok", "✓", "已验证", "已连接"]): tag = "success"
            elif "!" in entry or "⚠" in entry: tag = "warn"
            elif any(w in lo for w in ["x", "✕", "失败", "超时", "拒绝", "断开"]): tag = "error"
            elif "验证" in lo: tag = "verify"
            self._log.insert(tk.END, entry + "\n", tag)
            if int(self._log.index('end-1c').split('.')[0]) > MAX_LOG_LINES:
                self._log.delete('1.0', '100.0')
            self._log.see(tk.END)
            self._log.config(state=tk.DISABLED)
        except Exception: pass

    def _on_state(self, state):
        if self._closing: return
        self.root.after(0, self._update_ui, state)

    def _update_ui(self, state):
        if self._closing: return
        try: self.tray.update(state)
        except Exception: pass

    def _hide(self): self.root.withdraw()

    def _show(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def _quit(self):
        if self._closing: return
        self._closing = True
        log.info("退出中...")
        log.remove_cb(self._log_cb)
        self.ip_checker.stop()
        self.tunnel.stop()
        self.root.quit()
        self.root.destroy()

    def run(self):
        def net_loop():
            last = get_default_gw()
            while not self._closing:
                time.sleep(3)
                cur = get_default_gw()
                if cur != last:
                    last = cur
                    self.tunnel.on_network_change(cur is not None)
        self.netmon_thread = threading.Thread(target=net_loop, daemon=True)
        self.netmon_thread.start()
        if self.config.ip_check_interval > 0: self.ip_checker.start()
        self.tunnel.start()
        self.tray.run()
        self._update_ui(TunnelState.DISCONNECTED)
        if self.config.start_minimized: self.root.withdraw()
        self.root.mainloop()


# ============================================================
#   入口
# ============================================================

def _pid_exists(pid: int) -> bool:
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        SYNCHRONIZE = 0x00100000
        handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if handle: kernel32.CloseHandle(handle); return True
    except Exception: pass
    return False

def main():
    lock = SCRIPT_DIR / ".lock"
    for _ in range(5):
        if lock.exists():
            try:
                pid = int(lock.read_text().strip())
                if _pid_exists(pid): sys.exit(0)
                lock.unlink(missing_ok=True)
            except Exception: lock.unlink(missing_ok=True)
        try:
            lock.write_text(str(os.getpid()))
            atexit.register(lambda: lock.unlink(missing_ok=True))
            break
        except Exception: time.sleep(0.5)
    else: sys.exit(1)

    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("SSH.TunnelManager.v10")
    except Exception: pass

    config = Config.load()
    stats = ConnectionStats.load()
    log.info("=" * 44)
    log.info("  SSH 隧道管理器 v10")
    log.info(f"  目标: {config.ecs_host}:{config.remote_port}")
    log.info("=" * 44)
    App(config, stats).run()

if __name__ == "__main__":
    main()
